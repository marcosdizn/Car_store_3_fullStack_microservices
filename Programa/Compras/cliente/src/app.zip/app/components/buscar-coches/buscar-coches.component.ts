import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: 'app-buscar-coches',
  templateUrl: './buscar-coches.component.html',
  styleUrls: ['./buscar-coches.component.css']
})
export class BuscarCochesComponent {
buscarForm: FormGroup;

constructor(private fb: FormBuilder, private router: Router, private aRouter: ActivatedRoute) {

  this.buscarForm = this.fb.group({
    id_usuario: ['', Validators.required],//ANADIDO
    texto: ['', Validators.required],
    opcion: ['',Validators.required]
  })
}

}
