import { Component } from '@angular/core';

@Component({
  selector: 'app-comprar-coches',
  templateUrl: './comprar-coches.component.html',
  styleUrls: ['./comprar-coches.component.css']
})
export class ComprarCochesComponent {

}
