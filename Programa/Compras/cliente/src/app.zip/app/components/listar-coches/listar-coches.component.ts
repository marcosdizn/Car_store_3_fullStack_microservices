import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Coche } from 'src/app/models/coche';
import { CocheService } from 'src/app/services/coche.service';

@Component({
  selector: 'app-listar-coches',
  templateUrl: './listar-coches.component.html',
  styleUrls: ['./listar-coches.component.css']
})

export class ListarCochesComponent implements OnInit {
  listaForm: FormGroup;
  listCoches: Coche[] = [];
  opcion: string | null;
  texto: string | null;
  titulo = 'Listado de coches';
  id_usuario : string | null;

  constructor(private fb: FormBuilder, private _cocheService: CocheService, private toastr: ToastrService, private aRouter: ActivatedRoute) {
    this.listaForm = this.fb.group({
      id_usuario: ['', Validators.required],
    })
    this.opcion = this.aRouter.snapshot.paramMap.get('opcion');
    this.texto = this.aRouter.snapshot.paramMap.get('texto');
    this.id_usuario = this.aRouter.snapshot.paramMap.get('id_usuario');
  }

  ngOnInit(): void {
    this.obtenerCoches();
  }

  obtenerCoches() {
    
    console.log(this.id_usuario);
    if (this.id_usuario != null){
      if (this.opcion != null) //Cambiamos el título si es buscar
          this.titulo = 'Coches encontrados por ' + this.opcion + ':';
          
        if (this.opcion == 'id') { //Buscamos coches por id
          this._cocheService.getCochesPorId(this.texto).subscribe(data => {
            this.listCoches = data;
          }, error => {
            console.log(error);
          })

        } else if (this.opcion == 'marca') { //Buscamos coches por marca
          this._cocheService.getCochesPorMarca(this.texto).subscribe(data => {
            this.listCoches = data;
          }, error => {
            console.log(error);
          })

        } else { //Buscamos todos los coches
          this._cocheService.getCoches().subscribe(data => {
            this.listCoches = data;
          }, error => {
            console.log(error);
          })
        }
    }
    else{
      this.toastr.error('Necesitas introducir tu ID');
    }

  }

  eliminarCoche(id: any) {
    this._cocheService.eliminarCoche(id).subscribe(data => {
      this.toastr.error('El coche fue eliminado correctamente', 'Coche Eliminado');
      this.obtenerCoches();
    }, error => {
      console.log(error);
    })
  }

}
