export class Compra {
    _id?: number;
    cantidad: number;
    nombre_comprador: string;
    direccion: string;

    constructor(cantidad: number, nombre_comprador: string, direccion: string) {
        this.cantidad = cantidad;
        this.nombre_comprador = nombre_comprador;
        this.direccion = direccion;
    }
}