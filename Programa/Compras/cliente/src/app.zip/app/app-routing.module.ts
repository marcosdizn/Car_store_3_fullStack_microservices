import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// componentes
import { ListarCochesComponent } from './components/listar-coches/listar-coches.component';
import { CrearCocheComponent } from './components/crear-coche/crear-coche.component';
import { BuscarCochesComponent } from './components/buscar-coches/buscar-coches.component';
import { ComprarCochesComponent } from './components/comprar-coches/comprar-coches.component';

const routes: Routes = [
  { path: '', component: ListarCochesComponent},
  { path: 'buscar-coches', component: BuscarCochesComponent},
  { path: 'comprar-coches/:id_usuario', component: ComprarCochesComponent},
  { path: 'buscar-coches/:id_usuario/:opcion/:texto', component: ListarCochesComponent},//ANADIDO
  //{ path: 'buscar-coches/:id_usuario/:opcion', component: ListarCochesComponent},
  { path: 'listar-coches/:id_usuario', component: ListarCochesComponent}, //ANADIDO
  { path: '**', redirectTo: '', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
